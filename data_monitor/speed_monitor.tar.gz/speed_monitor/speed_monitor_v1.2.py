from __future__ import with_statement
import os
import paramiko
import time
import datetime
import xlwt
from time import sleep
import netifaces as ni
import smtplib
import string
from email.MIMEMultipart import MIMEMultipart
from email.MIMEText import MIMEText
from email.MIMEBase import MIMEBase
from email import encoders

#change "eth0" to a different interface name if needed
from_ip = ni.ifaddresses('eth0')[2][0]['addr']
#we are looking for the string 'from ip_address_of_server' in the logs.
statement = 'from ' + from_ip
#we need to change the log file everyday.
date_old = time.strftime("%x")
while 1:
	date_now = time.strftime("%x")
	#creating log file with the date as name eg: 06-06-16.log
	name = date_now + '.log'
	name = string.replace(name, '/', '-')
	#creating empty file with that name
	os.system('touch ./'+name)
	#starting iptraf in backgroung and setting the time out 1430 minutes
	command = 'sudo iptraf -i all -L ./'+name+'-t 1430 -B'
	os.system(command)
	time_old = int(time.strftime('%X')[:2]) - 1
	while 1:
		#This while loop and if statement make sure that mails are sent each hour
		if int(time.strftime('%X')[:2])>time_old:
			h = int(time.strftime('%X')[:2])
			time_old = h
			with open('./'+name) as f:
				lines = f.readlines()
			list = ''
			repeat = ''
			list_m = ''	
			print statement
			for line in lines:
				if statement in line:
					for s in line.split():
						if s.isdigit():
							#change this value to needed value (minimum threshold value)
							if(int(s)>100):
								list = list+ (line.split("to ",1)[1]).split(":",1)[0] + '\n'
								if list.count((line.split("to ",1)[1]).split(":",1)[0]) > 5:
									if((line.split("to ",1)[1]).split(":",1)[0] not in list_m):
										list_m = list_m + (line.split("to ",1)[1]).split(":",1)[0] + '\n'
			
			#Mailing
			fromaddr = "serverstatus@app.innoplexus.de"
			#add needed email addresses here.
			toaddr = ["suyash.masugade@innoplexus.com","bedapudi.praneeth@innoplexus.com","pradumna.panditrao@innoplexus.com"]
			#toaddr = ["bedapudi.praneeth@innoplexus.com"]
			for t in toaddr:
				msg = MIMEMultipart()
				msg['From'] = fromaddr
				msg['To'] = t
				#edit message subject here
				msg['Subject'] = statement + ' till ' + str(h) + ' :00' + ' time'
				#message body is the list of all ip addresses that we need		 
				body = list_m		 
				msg.attach(MIMEText(body, 'plain'))								
				server = smtplib.SMTP('email-smtp.us-east-1.amazonaws.com:587')
				server.starttls()
				server.login("AKIAJLVT63DSM247NJHQ", "AvAqwJImHHr9Ow98fImQo9E4GvI73WiKQgsSKAGfId70")
				text = msg.as_string()
				server.sendmail(fromaddr, t, text)
				server.quit()

			if(time.strftime("%x")>date_old):
				date_old = date_now
				break
