python congress_score.py
python merc.sharp_rename.py
python score_from_impact_factor.py
python last_name_sanitizer.py
python phase_rename.py
