Reports:
ES 1.7 vs 2.x indexing speeds - https://docs.google.com/a/innoplexus.com/document/d/1WIs3_9uw6OtNWEPfYR6V0aqxbTe56oRx6MeMpNUTIHg/edit?usp=sharing

OTP with Python (in PHP) - https://docs.google.com/a/innoplexus.com/document/d/1NK8UBrGH8P3Hw_jrsfLxlx_uyEoo0yxSNfvl3YYOoCI/edit?usp=sharing

Server auto Poweroff - https://docs.google.com/a/innoplexus.com/document/d/17HSG7Z55ejkJrYtcPWO62Vb9ToCB91zLx59PhDtyA8c/edit?usp=sharing

Elasticsearch (complete report) - https://docs.google.com/a/innoplexus.com/document/d/1K2JRwtJ6Qgn6VPFlR_gm8UCN7duutIt9a4tBzTtF8UI/edit?usp=sharing